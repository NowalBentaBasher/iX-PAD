# iXPAD
A simple text editor with bookmarking ability, syntax highlighting for source code, recent activity of the text editor.
Project move from https://github.com/s96Abrar/iXPAD
